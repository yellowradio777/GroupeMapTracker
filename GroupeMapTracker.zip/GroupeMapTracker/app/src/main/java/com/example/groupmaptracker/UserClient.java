package com.codingwithmitch.groupmaptracker;

import android.app.Application;

import com.codingwithmitch.groupmaptracker.models.User;


public class UserClient extends Application {

    private User user = null;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}
