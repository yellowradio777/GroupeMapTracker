package com.example.groupmaptracker.ui;

public interface IProfile {

    void onImageSelected(int resource);
}
